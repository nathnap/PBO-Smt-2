# FishLens — Panduan Setup NetBeans

## File yang Dikerjakan Masing-masing Anggota

| Anggota | File |
|---------|------|
| Anggota 3 | `interfaces/Displayable.java`, `interfaces/Manageable.java`, `service/LoginService.java`, `service/UserService.java` |
| Anggota 4 | `service/EnsiklopediaService.java`, `service/ForumService.java`, `service/ArtikelService.java` |
| Anggota 5 | `view/LoginFrame.java`, `view/MainFrame.java`, `view/FishLensApp.java` |

---

## Struktur Package

```
src/
└── fishlens/
    ├── interfaces/
    │   ├── Displayable.java          ← Anggota 3
    │   └── Manageable.java           ← Anggota 3
    ├── service/
    │   ├── LoginService.java         ← Anggota 3
    │   ├── UserService.java          ← Anggota 3
    │   ├── EnsiklopediaService.java  ← Anggota 4
    │   ├── ForumService.java         ← Anggota 4
    │   └── ArtikelService.java       ← Anggota 4
    ├── view/
    │   ├── LoginFrame.java           ← Anggota 5
    │   ├── MainFrame.java            ← Anggota 5
    │   └── FishLensApp.java          ← Anggota 5
    ├── model/                        ← File dari Anggota 1 & 2
    │   ├── User.java
    │   ├── Penghobi.java
    │   ├── Mentor.java
    │   ├── Ikan.java
    │   ├── Postingan.java
    │   └── Artikel.java
    └── DatabaseConnection.java       ← File dari Anggota 1
```

---

## Langkah Setup di NetBeans

### 1. Setup Database MySQL
1. Buka phpMyAdmin atau MySQL Workbench
2. Jalankan file `fishlens_db.sql`
3. Pastikan database `fishlens_db` berhasil dibuat

### 2. Konfigurasi DatabaseConnection.java
Edit file `DatabaseConnection.java` (milik Anggota 1):
```java
private static final String URL      = "jdbc:mysql://localhost:3306/fishlens_db";
private static final String USERNAME = "root";       // ganti jika beda
private static final String PASSWORD = "";           // ganti dengan password MySQL kamu
```

### 3. Tambahkan Library MySQL JDBC
Di NetBeans:
- Klik kanan project → Properties → Libraries → Add JAR/Folder
- Tambahkan `mysql-connector-j-8.x.x.jar`
- Download di: https://dev.mysql.com/downloads/connector/j/

### 4. Set Main Class
- Klik kanan project → Properties → Run
- Main Class: `fishlens.view.FishLensApp`

### 5. Run Program
- Tekan F6 atau klik tombol Run
- Window Login FishLens akan muncul

---

## Akun Testing (dari data sample SQL)

| Role     | Email              | Password |
|----------|--------------------|----------|
| Penghobi | nelson@test.com    | 12345    |
| Mentor   | mentor@test.com    | 12345    |

---

## Catatan Penting

- **Service tidak menyimpan state** — setiap method buka/tutup koneksi sendiri
- **LoginService tidak implements Manageable** — karena hanya mengelola sesi, bukan CRUD entity
- **Manageable** diimplementasikan oleh: UserService, EnsiklopediaService, ForumService, ArtikelService
- **Displayable** diimplementasikan oleh: User (abstract), Ikan, Postingan, Artikel
- GUI dibuat dengan **Java Swing** — compatible dengan NetBeans GUI Builder jika ingin dikembangkan
