/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pbo_yey;

/**
 *
 * @author hp
 */
public class PBO_Yey {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
