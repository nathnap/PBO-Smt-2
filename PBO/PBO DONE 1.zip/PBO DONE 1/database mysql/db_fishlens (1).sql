-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2026 at 08:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_fishlens`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_artikel`
--

CREATE TABLE `tabel_artikel` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `mentor_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_artikel`
--

INSERT INTO `tabel_artikel` (`id`, `judul`, `isi`, `mentor_id`, `status`) VALUES
(1, 'Panduan Dasar Membuat Aquascape untuk Pemula', 'Aquascape adalah seni mengatur tanaman air, batu, dan kayu di dalam akuarium. Langkah pertama yang harus disiapkan adalah...', 5, 'Approved'),
(2, 'Cara Ampuh Mengobati Penyakit White Spot (Ich)', 'White spot adalah penyakit umum pada ikan hias yang disebabkan oleh parasit. Gejalanya berupa bintik putih. Cara mengatasinya adalah dengan menaikkan suhu air ke 30°C dan memberikan...', 2, 'Approved'),
(3, 'Kombinasi Pakan Alami untuk Memaksimalkan Warna Ikan', 'Memberikan pelet saja tidak cukup. Untuk memaksimalkan warna ikan seperti Cupang atau Louhan, kita bisa memberikan pakan alami kaya karotenoid seperti udang kecil dan...', 2, 'Approved'),
(4, 'Mengenal Pentingnya Bakteri Starter (Filter Biologis)', 'Air yang bening belum tentu sehat untuk ikan. Kita membutuhkan koloni bakteri baik di dalam filter untuk mengubah amonia beracun dari kotoran ikan menjadi...', 5, 'Approved'),
(5, 'Tips Memilih Lampu LED Sesuai Kebutuhan Tanaman Air', 'Tidak semua lampu bisa digunakan untuk Aquascape. Pastikan memilih lampu dengan spektrum warna yang tepat (RGB) agar fotosintesis tanaman berjalan optimal...', 2, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_artikel_disimpan`
--

CREATE TABLE `tabel_artikel_disimpan` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `artikel_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tabel_ikan`
--

CREATE TABLE `tabel_ikan` (
  `id` int(11) NOT NULL,
  `nama_spesies` varchar(100) DEFAULT NULL,
  `habitat` varchar(100) DEFAULT NULL,
  `pakan` varchar(100) DEFAULT NULL,
  `penyakit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_ikan`
--

INSERT INTO `tabel_ikan` (`id`, `nama_spesies`, `habitat`, `pakan`, `penyakit`) VALUES
(1, 'Cupang (Betta)', 'Air Tawar', 'Pelet, Jentik Nyamuk', 'Busuk Sirip (Fin Rot), White Spot'),
(2, 'Koi', 'Air Tawar', 'Pelet, Cacing Sutra', 'Kutu Air (Argulus), Jamur'),
(3, 'Arwana Super Red', 'Air Tawar', 'Jangkrik, Kelabang, Udang', 'Sisik Berdiri (Dropsy), Mata Turun'),
(4, 'Guppy', 'Air Tawar', 'Kutu Air, Pelet Halus', 'White Spot (Ich), Kutu Jangkar'),
(5, 'Neon Tetra', 'Air Tawar', 'Cacing Sutra, Pelet Mikro', 'Penyakit Neon Tetra (NTD)'),
(6, 'Louhan (Flowerhorn)', 'Air Tawar', 'Pelet Khusus, Udang Kecil', 'Hole in the Head (HITH), Jamur Mulut'),
(7, 'Discus', 'Air Tawar', 'Cacing Darah (Bloodworm)', 'Cacing Pita, Infeksi Bakteri'),
(8, 'Molly', 'Air Tawar', 'Pelet, Alga', 'Jamur Mulut (Cotton Wool Disease)'),
(9, 'Platy', 'Air Tawar', 'Kutu Air, Pelet', 'Velvet, White Spot'),
(10, 'Swordtail (Ikan Pedang)', 'Air Tawar', 'Cacing Sutra, Pelet', 'Pembusukan Insang'),
(11, 'Mas Koki (Goldfish)', 'Air Tawar', 'Pelet, Sayuran Rebus', 'Gangguan Gelembung Renang (Swim Bladder)'),
(12, 'Manfish (Angelfish)', 'Air Tawar', 'Cacing Darah, Pelet', 'Hexamita, Cacing Usus'),
(13, 'Corydoras', 'Air Tawar', 'Pelet Tenggelam, Sisa Makanan', 'Infeksi Barbel (Sungut Merah)'),
(14, 'Pleco (Sapu-sapu)', 'Air Tawar', 'Alga, Timun, Pelet Tenggelam', 'Malnutrisi, Cacing Perut'),
(15, 'Oscar', 'Air Tawar', 'Ikan Kecil, Pelet Besar', 'Hole in the Head, Kembung'),
(16, 'Mas Koki Mutiara (Pearlscale)', 'Air Tawar', 'Pelet', 'Dropsy, Sembelit'),
(17, 'Botia (Clown Loach)', 'Air Tawar', 'Cacing Sutra, Pelet', 'White Spot (Ich)'),
(18, 'Clownfish (Nemo)', 'Air Laut', 'Udang Mysis, Pelet Laut', 'Brooklynelosis (Penyakit Ikan Badut)'),
(19, 'Blue Tang (Dory)', 'Air Laut', 'Alga, Pelet Laut', 'White Spot Laut (Marine Ich)'),
(20, 'Banggai Cardinalfish', 'Air Laut', 'Udang Karang (Artemia)', 'Infeksi Virus Banggai (BCIV)'),
(21, 'Lele', 'Air Payau', 'Pelet', 'Keracunan');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_ikan_favorit`
--

CREATE TABLE `tabel_ikan_favorit` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ikan_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_ikan_favorit`
--

INSERT INTO `tabel_ikan_favorit` (`id`, `user_id`, `ikan_id`) VALUES
(5, 4, 1),
(6, 4, 8),
(7, 4, 8),
(8, 4, 8),
(9, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_postingan`
--

CREATE TABLE `tabel_postingan` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_postingan`
--

INSERT INTO `tabel_postingan` (`id`, `judul`, `isi`, `user_id`, `tanggal`) VALUES
(2, 'Share: Setup Aquarium Guppy Minimalis Tanpa Kuras', 'Selamat sore teman-teman FishLens! Izin berbagi setup aquarium guppy saya ukuran 30cm. Saya pakai sistem Undergravel Filter (UGF) dan full tanaman air Anubias. Sudah 2 bulan air tetap bening kristal dan ikan sehat tanpa kuras total, cuma nambah air yang menguap saja.', 4, '2026-06-17'),
(3, 'Tanya: Perbedaan Guppy Jantan dan Betina?', 'Halo suhu, saya pemula. Gimana ya cara membedakan guppy jantan dan betina kalau ukurannya masih kecil?', 4, '2026-06-18'),
(4, 'Tips: Membuat Filter Kolam Koi Buatan Sendiri', 'Untuk teman-teman yang mau hemat, ini cara bikin filter chamber pakai drum plastik bekas. Siapkan kapas filter, bioball, dan pompa...', 3, '2026-06-18'),
(5, 'Share: Pentingnya Karantina Ikan Baru', 'Jangan langsung memasukkan ikan baru dibeli ke akuarium utama ya! Wajib karantina minimal 3 hari pakai methylene blue agar penyakit tidak menular.', 4, '2026-06-19'),
(6, 'Tanya: Daun Ketapang untuk Cupang', 'Apakah daun ketapang kering harus direbus dulu sebelum dimasukkan ke soliter cupang? Soalnya airnya jadi terlalu pekat.', 3, '2026-06-19'),
(8, 'ikan makan apa', 'pakan ikan', 3, '2026-06-19');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_postingan_disimpan`
--

CREATE TABLE `tabel_postingan_disimpan` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `postingan_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tabel_user`
--

CREATE TABLE `tabel_user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `keahlian` varchar(100) DEFAULT NULL,
  `status_verifikasi` tinyint(1) DEFAULT NULL,
  `total_sesi` varchar(50) DEFAULT NULL,
  `hobi_ikan` varchar(100) DEFAULT NULL,
  `tingkat_keanggotaan` varchar(50) DEFAULT NULL,
  `tanggal_daftar` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tabel_user`
--

INSERT INTO `tabel_user` (`id`, `nama`, `email`, `password`, `role`, `keahlian`, `status_verifikasi`, `total_sesi`, `hobi_ikan`, `tingkat_keanggotaan`, `tanggal_daftar`) VALUES
(1, 'Ferdi', 'ferdi@fishlens.com', 'ferdi123', 'Admin', NULL, NULL, NULL, NULL, NULL, '2026-06-17'),
(2, 'Aldo', 'aldo@mentor.com', 'aldo123', 'Mentor', 'Perawatan Ikan Air Tawar', 1, '12', NULL, NULL, '2026-06-17'),
(3, 'zidan', 'zidan@hobi.com', 'zidan123', 'Penghobi', NULL, NULL, NULL, 'Cupang, Koi', 'Senior', '2026-06-17'),
(4, 'Faiz', 'faiz@hobi.com', 'faiz123', 'Penghobi', NULL, NULL, NULL, 'Arwana, Louhan', 'Senior', '2026-06-17'),
(5, 'Nath', 'nath@mentor.com', 'nath123', 'Mentor', 'Aquascape & Desain Akuarium', 1, '25', NULL, NULL, '2026-06-17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_artikel`
--
ALTER TABLE `tabel_artikel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mentor_id` (`mentor_id`);

--
-- Indexes for table `tabel_artikel_disimpan`
--
ALTER TABLE `tabel_artikel_disimpan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `artikel_id` (`artikel_id`);

--
-- Indexes for table `tabel_ikan`
--
ALTER TABLE `tabel_ikan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_ikan_favorit`
--
ALTER TABLE `tabel_ikan_favorit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ikan_id` (`ikan_id`);

--
-- Indexes for table `tabel_postingan`
--
ALTER TABLE `tabel_postingan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tabel_postingan_disimpan`
--
ALTER TABLE `tabel_postingan_disimpan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `postingan_id` (`postingan_id`);

--
-- Indexes for table `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_artikel`
--
ALTER TABLE `tabel_artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tabel_artikel_disimpan`
--
ALTER TABLE `tabel_artikel_disimpan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tabel_ikan`
--
ALTER TABLE `tabel_ikan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tabel_ikan_favorit`
--
ALTER TABLE `tabel_ikan_favorit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tabel_postingan`
--
ALTER TABLE `tabel_postingan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tabel_postingan_disimpan`
--
ALTER TABLE `tabel_postingan_disimpan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tabel_user`
--
ALTER TABLE `tabel_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tabel_artikel`
--
ALTER TABLE `tabel_artikel`
  ADD CONSTRAINT `tabel_artikel_ibfk_1` FOREIGN KEY (`mentor_id`) REFERENCES `tabel_user` (`id`);

--
-- Constraints for table `tabel_artikel_disimpan`
--
ALTER TABLE `tabel_artikel_disimpan`
  ADD CONSTRAINT `tabel_artikel_disimpan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tabel_user` (`id`),
  ADD CONSTRAINT `tabel_artikel_disimpan_ibfk_2` FOREIGN KEY (`artikel_id`) REFERENCES `tabel_artikel` (`id`);

--
-- Constraints for table `tabel_ikan_favorit`
--
ALTER TABLE `tabel_ikan_favorit`
  ADD CONSTRAINT `tabel_ikan_favorit_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tabel_user` (`id`),
  ADD CONSTRAINT `tabel_ikan_favorit_ibfk_2` FOREIGN KEY (`ikan_id`) REFERENCES `tabel_ikan` (`id`);

--
-- Constraints for table `tabel_postingan`
--
ALTER TABLE `tabel_postingan`
  ADD CONSTRAINT `tabel_postingan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tabel_user` (`id`);

--
-- Constraints for table `tabel_postingan_disimpan`
--
ALTER TABLE `tabel_postingan_disimpan`
  ADD CONSTRAINT `tabel_postingan_disimpan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tabel_user` (`id`),
  ADD CONSTRAINT `tabel_postingan_disimpan_ibfk_2` FOREIGN KEY (`postingan_id`) REFERENCES `tabel_postingan` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
